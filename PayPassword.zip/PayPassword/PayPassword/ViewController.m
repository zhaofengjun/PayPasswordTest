//
//  ViewController.m
//  PayPassword
//
//  Created by 123 on 16/9/19.
//  Copyright © 2016年 123. All rights reserved.
//

#import "ViewController.h"
#import "GAPayPasswordView.h"
@interface ViewController ()<GAPayPasswordViewDelegate>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    GAPayPasswordView *view = [[GAPayPasswordView alloc] initWithFrame:(CGRectMake(0, 100, self.view.frame.size.width, 60))];
    view.delegate = self;
    view.margin_warp = 20;
    view.margin_color = [UIColor grayColor];
    [self.view addSubview:view];
    [view touchBegin];
}
-(void)actionPayPassword:(NSString *)password
{
    NSLog(@"%@",password);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
