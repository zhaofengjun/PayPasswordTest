//
//  GAPayPasswordView.h
//  PayPassword
//
//  Created by 123 on 16/9/19.
//  Copyright © 2016年 123. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol GAPayPasswordViewDelegate <NSObject>

-(void)actionPayPassword:(NSString *)password;

@end

@interface GAPayPasswordView : UIView
@property(nonatomic, weak)id<GAPayPasswordViewDelegate> delegate;
@property(nonatomic, assign)CGFloat margin_warp;
@property(nonatomic, strong)UIColor *margin_color;
-(void)touchBegin;
@end
