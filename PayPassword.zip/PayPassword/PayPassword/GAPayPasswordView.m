//
//  GAPayPasswordView.m
//  PayPassword
//
//  Created by 123 on 16/9/19.
//  Copyright © 2016年 123. All rights reserved.
//

#import "GAPayPasswordView.h"
#import "UIViewExt.h"

@interface GAPayPasswordView ()
@property(nonatomic, strong)UITextField *backGround;
@property(nonatomic, strong)NSMutableArray *dataSource;
@property(nonatomic, strong)NSMutableArray *lineDataSource;
@property(nonatomic, strong)NSString *password;
@property(nonatomic, strong)UIView *bgView;
@end
//物理屏幕宽度
#define KScreenWidth  [UIScreen mainScreen].bounds.size.width

//物理屏幕高度
#define KScreenHeight  [UIScreen mainScreen].bounds.size.height

@implementation GAPayPasswordView



-(instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self addChildView];
    }
    return self;
}

-(void)addChildView
{
    self.dataSource = [NSMutableArray new];
    self.lineDataSource = [NSMutableArray new];
    
    self.backGround = [[UITextField alloc] init];
    self.backGround.hidden = YES;
    self.backGround.keyboardType = UIKeyboardTypeNumberPad;
    [self.backGround addTarget:self action:@selector(actionPasswordChange:) forControlEvents:UIControlEventEditingChanged];
    [self addSubview:self.backGround];
    self.bgView = [[UIView alloc] init];
    self.bgView.layer.borderWidth = 1.0;
    for (int i = 0; i < 6; i++) {
        UIButton *button = [[UIButton alloc] init];
        button.titleLabel.font = [UIFont systemFontOfSize:30.0];
        [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        button.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
        [button addTarget:self action:@selector(touchBegin) forControlEvents:UIControlEventTouchUpInside];
     
        [self.dataSource addObject:button];
        [self.bgView addSubview:button];
        if (i < 5) {
            UILabel *lineLbale = [[UILabel alloc] init];
            lineLbale.backgroundColor = [UIColor blackColor];
            [self.bgView addSubview:lineLbale];
            [self.lineDataSource addObject:lineLbale];
        }
       
    }

    [self addSubview:self.bgView];
}

-(void)touchBegin
{
  [self.backGround becomeFirstResponder];
}

- (void)actionPasswordChange:(UITextField*)textField
{
    NSString *text = textField.text;
    if (text.length > self.dataSource.count) {
        textField.text = [text substringToIndex:6];
        self.password = [text substringToIndex:6];
    }else {
        self.password = text;
    }
    if (self.password.length == self.dataSource.count) {
        [self actionBackPassword];
    }
    for (int i = 0; i < self.dataSource.count; i++) {
        UIButton *btn = [self.dataSource objectAtIndex:i];
        NSString *str = @"";
        if (i < self.password.length) {
            str = [self.password substringWithRange:NSMakeRange(i, 1)];
            str = @"●";
        }
        [btn setTitle:str forState:UIControlStateNormal];
    }
}

-(void)actionBackPassword
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(actionPayPassword:)]) {
        [self.delegate actionPayPassword:self.password];
    }
}

-(void)layoutSubviews
{
    [super layoutSubviews];
    CGFloat width = (self.width - _margin_warp * 2 )/6 ;
    self.backGround.frame = CGRectMake(_margin_warp, self.height/2 - width/2, width * 6 , width);
    self.bgView.frame = self.backGround.frame;
    for (int i = 0; i < self.dataSource.count; i++) {
        UIButton *btn = self.dataSource[i];
        btn.frame = CGRectMake( i * width,0, (width - 1), (width - 1));
        if (i < self.lineDataSource.count) {
            UILabel *line = self.lineDataSource[i];
            line.backgroundColor = _margin_color;
            line.frame = CGRectMake(btn.right, 0, 1, width);
        }
    }
    self.bgView.layer.borderColor = _margin_color.CGColor;
}

-(void)setMargin_warp:(CGFloat)margin_warp
{
    _margin_warp = margin_warp;

    [self setNeedsLayout];
}
-(void)setMargin_color:(UIColor *)margin_color
{
    _margin_color = margin_color;
    [self setNeedsLayout];
}
@end
